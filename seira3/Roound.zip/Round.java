import java.util.*;

import java.util.concurrent.TimeUnit;

import java.io.File;
import java.io.FileNotFoundException;

public class Round{

    public static void main(String args[]) throws FileNotFoundException{
       //long start=System.currentTimeMillis();
       
       Scanner s = new Scanner(new File(args[0]));
       
       int n = s.nextInt();
       int v = s.nextInt();
       int list[];
       list = new int[n];
       
       int j;
       for(int i = 0; i < v; i++){
         j = s.nextInt();
         list[j]++;
       } 
       s.close();
      // long end_making_the_list = System.currentTimeMillis()-start;
      // System.out.println("list: "+end_making_the_list);
       VCities cities =  new VCities(list, v, n);
       ZMyResult mr;
       mr = cities.getMandC();
      // long findtheresult = System.currentTimeMillis()-start;
      // System.out.println("result: "+findtheresult);
       int M = mr.getFirst();
       int C = mr.getSecond();
        
       System.out.println(M+" "+C);       
       
      
       //long finish = System.currentTimeMillis();
       //long timeElapsed = finish - start;
       //System.out.println(timeElapsed);

    }


} 